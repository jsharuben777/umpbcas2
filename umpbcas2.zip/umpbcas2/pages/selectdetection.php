<!DOCTYPE html>
<html>
<head>
<style>
.button {
    border: none;
  color: white;
  padding: 30px 60px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 30px;
  margin: 100px 50px;
  transition-duration: 0.2s;
  cursor: pointer;
  margin: 40px;
    width: 25%;
    padding-top:25px;
    top: 50%;
    left: 50%;
    margin-top: 40px ;
    margin-left: 880px ;

   
  
}

.button1 {
  background-color: white;
  color: black;
  border: 2px solid #4CAF50;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
}

.button2 {
  background-color: white;
  color: black;
  border: 2px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}
.button3 {
  background-color: white;
  color: black;
  border: 2px solid #f44336;
}

.button3:hover {
  background-color: #f44336;
  color: white;
}

.button4 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
}

.button4:hover {
  background-color: #555555;
  color: white;
}

.button5 {
  background-color: white;
  color: black;
  border: 2px solid #FF00FF;
}

.button5:hover {
  background-color: #FF00FF;
  color: white;
}

h1{  
    text-align: center; 
    color: white; 


}
h3{  
    text-align: center;  
    color: white; 

}
html {
  background-color: #27613b;
}

</style>
</head>
<body>

<div class="container">
    <div class ="w3-green w3-hover-shadow w3-center">
    <h1> Cyber Attack Detection list 2021 </h1>
    <h3> Choose specific quarter to view Data</h3>
<a href="http://localhost/umpbcas2/pages/q1_analytics.php"> <button class="button button1">Q1 2021</button> </a>
<br>
<a href="http://localhost/umpbcas2/pages/q2_analytics.php"><button class="button button2">Q2 2021</button> </a>
<br>
<a href="http://localhost/umpbcas2/pages/q3_analytics.php"><button class="button button3">Q3 2021</button> </a>
<br>
<a href="http://localhost/umpbcas2/pages/q4_analytics.php"><button class="button button4">Q4 2021</button> </a>
<br>
<a href="http://localhost/umpbcas2/pages/homepage.php"><button class="button button5">Home</button> </a>
</div>
</div>

</body>
</html>
