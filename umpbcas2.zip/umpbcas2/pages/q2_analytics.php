<!DOCTYPE html>
<html>
<head>
<style>
.button {
    border: none;
  color: white;
  padding: 30px 60px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 30px;
  margin: 100px 50px;
  transition-duration: 0.2s;
  cursor: pointer;
  margin: 40px;
    width: 25%;
    padding-top:25px;
    top: 50%;
    left: 50%;
    margin-top: 40px ;
    margin-left: 880px ;

   
  
}

.button1 {
  background-color: white;
  color: black;
  border: 2px solid #4CAF50;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
}

.button2 {
  background-color: white;
  color: black;
  border: 2px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}
.button3 {
  background-color: white;
  color: black;
  border: 2px solid #f44336;
}

.button3:hover {
  background-color: #f44336;
  color: white;
}

.button4 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
}

.button4:hover {
  background-color: #555555;
  color: white;
}

h1{  
    text-align: center; 
    color: white; 


}
h3{  
    text-align: center;  
    color: white; 

}
html {
  background-color: #27613b;
}


</style>
</head>
<body>

<div class="container">
<h1> QUARTER 2 CYBER ATTACK DETECTION DATA </h1>
    <h3> Choose specific month to view Data</h3>
<a href="http://localhost/umpbcas2/pages/detectionmonth/apr_detectiondata.php"> <button class="button button1">APR 2021</button> </a>
<a href="http://localhost/umpbcas2/pages/detectionmonth/may_detectiondata.php"> <button class="button button2">MAY 2021</button> </a>
<a href="http://localhost/umpbcas2/pages/detectionmonth/jun_detectiondata.php"><button class="button button3">JUN 2021</button> </a>

</div>

</body>
</html>
